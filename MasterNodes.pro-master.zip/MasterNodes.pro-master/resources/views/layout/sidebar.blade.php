<div id="mySidenav" class="sidenav">
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
    <a href="/"><i class="fa fa-home" aria-hidden="true"></i> Home</a>
    <a href="/active"><i class="fa fa-rss" aria-hidden="true"></i> Active</a>
    <a href="/soon"><i class="fa fa-pause" aria-hidden="true"></i> Coming Soon</a>
    <a href="/donate"><i class="fa fa-money" aria-hidden="true"></i> Need Donation's</a>
</div>
<span onclick="openNav()" class="sidebarOpen"><i class="fa fa-bars fa-3x" aria-hidden="true"></i></span>