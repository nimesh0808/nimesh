<footer class="navbar-fixed-bottom" style="text-align: center">
    <div>
        <div class="col-md-3 col-xs-12">
            Help Make this software Better: <a href="{!! env('GITHUB') !!}" target="_blank">GitHub</a>
        </div>
    </div>
</footer>