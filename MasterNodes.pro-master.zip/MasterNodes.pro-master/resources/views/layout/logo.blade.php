<div class="row"  style="text-align: center;">
    <div class="col-lg-5 col-md-5 hidden-sm hidden-xs"></div>
    <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
        <div style="display: inline-block;">
            <a href="/"><img src="/img/MPlogo2.svg" class="logo img-responsive"><Br>MasterNodes.pro</a><br>
        </div>
    </div>
    <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
        Like what you see?<br>
        DONATE: <a href="bitcoin:1AYcZq9qcNcF5yaBb1jWsLn9KSF2UDAJzq" target="_blank"
           data-toggle="popover" data-trigger="hover" title="bitcoin address"
           data-html="true" data-content="<img src='https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=1AYcZq9qcNcF5yaBb1jWsLn9KSF2UDAJzq' width='150'>">
            1AYcZq9qcNcF5yaBb1jWsLn9KSF2UDAJzq
        </a>
    </div>
</div>